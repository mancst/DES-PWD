#!/bin/bash

./stop.sh
sleep 1;
./start.sh

