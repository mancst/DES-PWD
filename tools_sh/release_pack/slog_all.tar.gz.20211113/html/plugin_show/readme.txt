插件看板目录, 每个插件的看板目录以 插件名_show 命名
例如插件：open_source_star 的看板目录为 open_source_star_show


