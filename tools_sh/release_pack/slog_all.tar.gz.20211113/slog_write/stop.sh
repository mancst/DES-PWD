#!/bin/bash
. ../tools_sh/stop_comm.sh
stop_proc slog_write
