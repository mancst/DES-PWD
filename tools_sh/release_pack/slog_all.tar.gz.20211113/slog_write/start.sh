#!/bin/bash
. ../tools_sh/start_comm.sh
start_proc slog_write
